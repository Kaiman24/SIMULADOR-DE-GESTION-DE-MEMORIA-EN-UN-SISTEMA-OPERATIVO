# gui.py

import tkinter as tk
from memory_simulator import MemorySimulator

def initialize_fixed():
    partition_size = int(entry_partition_size.get())
    simulator.fixed_partitioning(partition_size)
    update_display(f"Particiones fijas inicializadas con tamaño {partition_size}.")

def initialize_dynamic():
    simulator.dynamic_partitioning()
    update_display("Partición dinámica inicializada.")

def add_process():
    process_id = entry_process_id.get()
    process_size = int(entry_process_size.get())
    if var_partition_type.get() == "Fixed":
        result = simulator.add_process_fixed(process_id, process_size)
    else:
        result = simulator.add_process_dynamic(process_id, process_size)
    update_display(result)

def update_display(message):
    display_label.config(text=message)
    memory_label.config(text=simulator.display_memory())

# Configuración del simulador
total_memory = 1000  # Ejemplo de memoria total en unidades
simulator = MemorySimulator(total_memory)

# Configuración de la interfaz Tkinter
root = tk.Tk()
root.title("Simulador de Gestión de Memoria")

frame = tk.Frame(root)
frame.pack(pady=10)

# Selección del tipo de particionamiento
var_partition_type = tk.StringVar(value="Fixed")
tk.Label(frame, text="Tipo de Particionamiento:").grid(row=0, column=0)
tk.Radiobutton(frame, text="Fijo", variable=var_partition_type, value="Fixed").grid(row=0, column=1)
tk.Radiobutton(frame, text="Dinámico", variable=var_partition_type, value="Dynamic").grid(row=0, column=2)

# Campos de entrada
tk.Label(frame, text="Tamaño de Partición (Fijo):").grid(row=1, column=0)
entry_partition_size = tk.Entry(frame)
entry_partition_size.grid(row=1, column=1)

tk.Label(frame, text="ID del Proceso:").grid(row=2, column=0)
entry_process_id = tk.Entry(frame)
entry_process_id.grid(row=2, column=1)

tk.Label(frame, text="Tamaño del Proceso:").grid(row=3, column=0)
entry_process_size = tk.Entry(frame)
entry_process_size.grid(row=3, column=1)

# Botones
tk.Button(frame, text="Inicializar Fijo", command=initialize_fixed).grid(row=4, column=0, pady=5)
tk.Button(frame, text="Inicializar Dinámico", command=initialize_dynamic).grid(row=4, column=1, pady=5)
tk.Button(frame, text="Agregar Proceso", command=add_process).grid(row=5, column=0, columnspan=2)

# Etiquetas de salida
display_label = tk.Label(root, text="")
display_label.pack()
memory_label = tk.Label(root, text="")
memory_label.pack()

root.mainloop()

# memory_simulator.py

class MemorySimulator:
    def __init__(self, total_memory):
        self.total_memory = total_memory
        self.fixed_partitions = []
        self.dynamic_memory = []
        self.partition_size = None

    def fixed_partitioning(self, partition_size):
        """Configura particiones fijas en memoria."""
        self.partition_size = partition_size
        num_partitions = self.total_memory // partition_size
        self.fixed_partitions = [None] * num_partitions

    def dynamic_partitioning(self):
        """Configura una partición dinámica (memoria única)."""
        self.dynamic_memory = [{"size": self.total_memory, "process": None}]

    def add_process_fixed(self, process_id, process_size):
        """Agrega un proceso en particionamiento fijo."""
        for i in range(len(self.fixed_partitions)):
            if self.fixed_partitions[i] is None and process_size <= self.partition_size:
                self.fixed_partitions[i] = process_id
                return f"Proceso {process_id} agregado en partición fija {i+1}."
        return "No hay espacio disponible en las particiones fijas."

    def add_process_dynamic(self, process_id, process_size):
        """Agrega un proceso en particionamiento dinámico."""
        for block in self.dynamic_memory:
            if block["process"] is None and block["size"] >= process_size:
                block["process"] = process_id
                return f"Proceso {process_id} agregado en partición dinámica de tamaño {block['size']}."
        return "No hay espacio suficiente en la memoria dinámica."

    def display_memory(self):
        """Muestra el estado actual de la memoria."""
        if self.fixed_partitions:
            return f"Particiones Fijas: {self.fixed_partitions}"
        elif self.dynamic_memory:
            return f"Memoria Dinámica: {[(block['size'], block['process']) for block in self.dynamic_memory]}"
